export const apiVersion = process.env.NEXT_PUBLIC_SANITY_API_VERSION || "2026-03-08";
export const dataset = process.env.NEXT_PUBLIC_SANITY_DATASET || "production";
export const projectId = process.env.NEXT_PUBLIC_SANITY_PROJECT_ID || "";
export const writeToken = process.env.SANITY_API_WRITE_TOKEN || "";
